/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelos;

/**
 *
 * @author vinic
 */
public class ModeloTitulo {
    private int prazo;
    private String isbn;
    private int edição;
    private int ano;
    private int codArea;
    private int codautor;
    private int codtitulo;
    private String pesquisa;

    public int getCodtitulo() {
        return codtitulo;
    }

    public void setCodtitulo(int codtitulo) {
        this.codtitulo = codtitulo;
    }

    public int getPrazo() {
        return prazo;
    }

    public void setPrazo(int prazo) {
        this.prazo = prazo;
    }

    public String getIsbn() {
        return isbn;
    }

    public void setIsbn(String isbn) {
        this.isbn = isbn;
    }

    public int getEdição() {
        return edição;
    }

    public void setEdição(int edição) {
        this.edição = edição;
    }

    public int getAno() {
        return ano;
    }

    public void setAno(int ano) {
        this.ano = ano;
    }

    public int getCodArea() {
        return codArea;
    }

    public void setCodArea(int codArea) {
        this.codArea = codArea;
    }

    public int getCodautor() {
        return codautor;
    }

    public void setCodautor(int cod) {
        this.codautor = codautor;
    }

    public String getPesquisa() {
        return pesquisa;
    }

    public void setPesquisa(String pesquisa) {
        this.pesquisa = pesquisa;
    }
}
