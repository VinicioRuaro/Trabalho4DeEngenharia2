/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelos;

public class ModeloAluno {

    /**
     * @return the codaluno
     */
    public int getCodaluno() {
        return codaluno;
    }

    /**
     * @param codaluno the codaluno to set
     */
    public void setCodaluno(int codaluno) {
        this.codaluno = codaluno;
    }

    
    private int codaluno;
    private String NomeAluno;
    private int CPFAluno;
    private int CEPAluno;
    private String EndereçoALuno;
    private String BairroAluno;
    private String Complemento;
    private String pesquisa;
    private int emprestimos;
       

    public String getNomeAluno() {
        return NomeAluno;
    }

    public void setNomeAluno(String NomeAluno) {
        this.NomeAluno = NomeAluno;
    }

    public int getCPFAluno() {
        return CPFAluno;
    }

    public void setCPFAluno(int CPFAluno) {
        this.CPFAluno = CPFAluno;
    }

    public int getCEPAluno() {
        return CEPAluno;
    }

    public void setCEPAluno(int CEPAluno) {
        this.CEPAluno = CEPAluno;
    }

    public String getEndereçoALuno() {
        return EndereçoALuno;
    }

    public void setEndereçoALuno(String EndereçoALuno) {
        this.EndereçoALuno = EndereçoALuno;
    }

    public String getBairroAluno() {
        return BairroAluno;
    }

    public void setBairroAluno(String BairroAluno) {
        this.BairroAluno = BairroAluno;
    }

    public String getComplemento() {
        return Complemento;
    }

    public void setComplemento(String Complemento) {
        this.Complemento = Complemento;
    }
    
       private String string;

    /**
     * Get the value of string
     *
     * @return the value of string
     */
    public String getString() {
        return string;
    }

    /**
     * Set the value of string
     *
     * @param string new value of string
     */
    public void setString(String string) {
        this.string = string;
    }

    public String getPesquisa() {
        return pesquisa;
    }

    public void setPesquisa(String pesquisa) {
        this.pesquisa = pesquisa;
    }

    public int getEmprestimos() {
        return emprestimos;
    }

    public void setEmprestimos(int emprestimos) {
        this.emprestimos = emprestimos;
    }

    
}
