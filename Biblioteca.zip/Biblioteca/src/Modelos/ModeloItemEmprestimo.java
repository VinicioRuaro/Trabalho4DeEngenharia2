/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelos;

/**
 *
 * @author vinic
 */
public class ModeloItemEmprestimo {
    
    
    private int codlivro;
    private int codemprestimo;
    private int cpdaluno;
    private int diap;
    private int mesp;
    private int anop;
    private int diad;
    private int mesd;
    private int anod;
    private int cod;
    private int devolvido;
    private String Pesquisa;

    public int getCodlivro() {
        return codlivro;
    }

    public void setCodlivro(int codlivro) {
        this.codlivro = codlivro;
    }

    public int getCodemprestimo() {
        return codemprestimo;
    }

    public void setCodemprestimo(int codemprestimo) {
        this.codemprestimo = codemprestimo;
    }

    public int getCpdaluno() {
        return cpdaluno;
    }

    public void setCpdaluno(int codaluno) {
        this.cpdaluno = codaluno;
    }

    public int getDiap() {
        return diap;
    }

    public void setDiap(int diap) {
        this.diap = diap;
    }

    public int getMesp() {
        return mesp;
    }

    public void setMesp(int mesp) {
        this.mesp = mesp;
    }

    public int getAnop() {
        return anop;
    }

    public void setAnop(int anop) {
        this.anop = anop;
    }

    public int getDiad() {
        return diad;
    }

    public void setDiad(int diad) {
        this.diad = diad;
    }

    public int getMesd() {
        return mesd;
    }

    public void setMesd(int mesd) {
        this.mesd = mesd;
    }

    public int getAnod() {
        return anod;
    }

    public void setAnod(int anod) {
        this.anod = anod;
    }

    public int getCod() {
        return cod;
    }

    public void setCod(int cod) {
        this.cod = cod;
    }

    public int getDevolvido() {
        return devolvido;
    }

    public void setDevolvido(int devolvido) {
        this.devolvido = devolvido;
    }

    public String getPequisa() {
        return Pesquisa;
    }

    public void setPequisa(String pesquisa) {
        this.Pesquisa = pesquisa;
    }
}
