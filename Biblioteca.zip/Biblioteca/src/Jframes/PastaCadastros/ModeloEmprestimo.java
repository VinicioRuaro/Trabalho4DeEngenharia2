/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Jframes.PastaCadastros;

/**
 *
 * @author vinic
 */
public class ModeloEmprestimo {
    private int cod;
    private int codaluno;
    private int diae;
    private int mese;
    private int anoe;
    private int qlivros;
    private String pesquisa;

    public int getCod() {
        return cod;
    }

    public void setCod(int cod) {
        this.cod = cod;
    }

    public int getCodaluno() {
        return codaluno;
    }

    public void setCodaluno(int codaluno) {
        this.codaluno = codaluno;
    }

    public int getDiae() {
        return diae;
    }

    public void setDiae(int diae) {
        this.diae = diae;
    }

    public int getMese() {
        return mese;
    }

    public void setMese(int mese) {
        this.mese = mese;
    }

    public int getAnoe() {
        return anoe;
    }

    public void setAnoe(int anoe) {
        this.anoe = anoe;
    }

    public int getQlivros() {
        return qlivros;
    }

    public void setQlivros(int qlivros) {
        this.qlivros = qlivros;
    }

    public String getPesquisa() {
        return pesquisa;
    }

    public void setPesquisa(String pesquisa) {
        this.pesquisa = pesquisa;
    }
}
