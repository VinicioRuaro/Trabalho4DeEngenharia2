/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Dao;
import Arquivos.ConecaoBD;
import Jframes.PastaCadastros.ModeloEmprestimo;
import Modelos.ModeloItemEmprestimo;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.swing.JOptionPane;
/**
 *
 * @author vinic
 */
public class DaoEmprestimo {
    
    
        
        ConecaoBD conex = new ConecaoBD();
        
        public void Salvar(ModeloEmprestimo mod){
            try {
                conex.conexao();
                PreparedStatement pst = conex.con.prepareStatement("insert into emprestimo(codaluno,diae,mese,anoe) values(?,?,?,?)");
                pst.setInt(1, mod.getCodaluno());
                pst.setInt(2, mod.getDiae());
                pst.setInt(3, mod.getMese());
                pst.setInt(4, mod.getAnoe());
                
                pst.execute();
                
                JOptionPane.showMessageDialog(null, "Emprestimo salvo com sucesso.");
                conex.desconecta();
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(null, "Não foi possivel salvar o o emprestimo.\n" +ex);
            }
        }
        
        public ModeloEmprestimo buscarcod(ModeloEmprestimo modPesquisa){
            
            try {
                conex.conexao();           
                
                conex.executaSQL("select *from itememprestimo where cod like'%"+modPesquisa.getPesquisa()+"%'");       
                conex.rs.first();        
                System.out.println("Pesquisa feita no banco");
                conex.desconecta();
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(null, "Não foi possivel buscar no banco\n" +ex);
            }
            return modPesquisa;
        }
        
        
    

}
