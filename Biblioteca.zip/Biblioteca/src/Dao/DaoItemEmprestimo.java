/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Dao;

import Arquivos.ConecaoBD;
import Modelos.ModeloItemEmprestimo;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.swing.JOptionPane;
/**
 *
 * @author vinic
 */
public class DaoItemEmprestimo {
 
        ConecaoBD conex = new ConecaoBD();
        
        public void Salvar(ModeloItemEmprestimo mod){
            try {
                conex.conexao();
                PreparedStatement pst = conex.con.prepareStatement("insert into itememprestimo(codlivro,codemprestimo,codaluno,diap,mesp,anop,devolvido,diad,mesd,anod) values(?,?,?,?,?,?,?,?,?,?)");
                pst.setInt(1, mod.getCodlivro());
                pst.setInt(2, mod.getCodemprestimo());
                pst.setInt(3, mod.getCpdaluno());
                pst.setInt(4, mod.getDiap());
                pst.setInt(5, mod.getMesp());
                pst.setInt(6, mod.getAnop());
                pst.setInt(7, 0);
                pst.setInt(8, mod.getDiad());
                pst.setInt(9, mod.getMesd());
                pst.setInt(10, mod.getAnod());
                pst.execute();
                
                JOptionPane.showMessageDialog(null, "Item salvo com sucesso.");
                conex.desconecta();
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(null, "Não foi possivel salvar o Livro.\n" +ex);
            }
        }
        
        public ModeloItemEmprestimo buscarcod(ModeloItemEmprestimo modPesquisa){
            
            try {
                conex.conexao();           
                
                conex.executaSQL("select *from itememprestimo where cod like'%"+modPesquisa.getPequisa()+"%'");       
                conex.rs.first();        
                System.out.println("Pesquisa feita no banco");
                conex.desconecta();
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(null, "Não foi possivel buscar no banco\n" +ex);
            }
            return modPesquisa;
        }
        
        public void editar(int cod){
            try {
                conex.conexao();
                PreparedStatement pst = conex.con.prepareStatement("update itememprestimo set devolvido=? where cod=?");  
                pst.setInt(1, 1);   
                pst.setInt(2, cod);
                pst.execute();
                JOptionPane.showMessageDialog(null, "Dados alterados com sucesso!");
                System.out.println("Dados do Livro alterados com sucesso.");
                conex.desconecta();
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(null, "Dados não alterados.\nErro:"+ex.getMessage());
            }
            }
       
}

