/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controle;

import Arquivos.ConecaoBD;
import Modelos.ModeloLivro;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.swing.JOptionPane;

/**
 *
 * @author vinic
 */
public class ControleLivro {
    
    
        ConecaoBD conex = new ConecaoBD();
        
        public void Salvar(ModeloLivro mod){
            try {
                conex.conexao();
                PreparedStatement pst = conex.con.prepareStatement("insert into livro(disponivel,exemplarbiblioteca,codtitulo) values(?,?,?)");
                pst.setInt(1, mod.getDisponivel());
                pst.setInt(2, mod.getExemplarBiblioteca());
                pst.setString(3, mod.getIsbn());
                pst.execute();
                JOptionPane.showMessageDialog(null, "Livro salvo com sucesso.");
                System.out.println("Dados do Livro salvo no banco.");
                conex.desconecta();
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(null, "Não foi possivel salvar o Livro.\n" +ex);
            }
        }
        
        public ModeloLivro buscarcod(ModeloLivro modPesquisa){
            
            try {
                conex.conexao();           
                
                conex.executaSQL("select *from livro where cod like'%"+modPesquisa.getPesquisa()+"%'");       
                conex.rs.first();        
                System.out.println("Pesquisa feita no banco");
                conex.desconecta();
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(null, "Não foi possivel buscar no banco\n" +ex);
            }
            return modPesquisa;
        }
        
        public void editardis(int cod){
            try {
                conex.conexao();
                PreparedStatement pst = conex.con.prepareStatement("update livro set disponivel=? where cod=?");
                pst.setInt(1, 1);   
                pst.setInt(2, cod);
                pst.execute();
                
                JOptionPane.showMessageDialog(null, "Dados alterados com sucesso!");
                System.out.println("Dados do Livro alterados com sucesso.");
                conex.desconecta();
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(null, "Dados não alterados.\nErro:"+ex.getMessage());
            }
            
            }public void editarndis(int cod){
            try {
                conex.conexao();
                PreparedStatement pst = conex.con.prepareStatement("update livro set disponivel=? where cod=?");
                pst.setInt(1, 0);   
                pst.setInt(2, cod);
                pst.execute();
                
                JOptionPane.showMessageDialog(null, "Dados alterados com sucesso!");
                System.out.println("Dados do Livro alterados com sucesso.");
                conex.desconecta();
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(null, "Dados não alterados.\nErro:"+ex.getMessage());
            }
            }
        
        
    
}
