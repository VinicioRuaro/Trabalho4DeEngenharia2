/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controle;

import Arquivos.ConecaoBD;
import Modelos.ModeloArea;
import Modelos.ModeloAutor;
import Modelos.ModeloTitulo;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.swing.JOptionPane;

/**
 *
 * @author vinic
 */
public class ControleTitulo {
    
    
        ConecaoBD conex = new ConecaoBD();
        
        public void Salvar(ModeloTitulo mod){
            try {
                conex.conexao();
                PreparedStatement pst = conex.con.prepareStatement("insert into titulo(prazo,isbn,edicao,ano,codautor,codarea) values(?,?,?,?,?,?)");
                pst.setInt(1, mod.getPrazo());
                pst.setString(2, mod.getIsbn());
                pst.setInt(3, mod.getEdição());
                pst.setInt(4, mod.getAno());
                pst.setInt(5, mod.getCodautor());
                pst.setInt(6, mod.getCodArea());
                pst.execute();
                JOptionPane.showMessageDialog(null, "Titulo salvo com sucesso.");
                System.out.println("Dados do Titulo salvo no banco.");
                conex.desconecta();
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(null, "Não foi possivel salvar a Area.\n" +ex);
            }
        }
        
        public ModeloTitulo buscaarea(ModeloTitulo modPesquisa){
            
            try {
                conex.conexao();           
                
                conex.executaSQL("select *from titulo where isbn like'%"+modPesquisa.getPesquisa()+"%'");       
                conex.rs.first();         
                modPesquisa.setPrazo(conex.rs.getInt("prazo"));
                modPesquisa.setIsbn(conex.rs.getString("isbn"));
                modPesquisa.setEdição(conex.rs.getInt("edicao"));
                modPesquisa.setAno(conex.rs.getInt("ano"));
                modPesquisa.setCodautor(conex.rs.getInt("codautor"));
                modPesquisa.setCodArea(conex.rs.getInt("codarea"));
                modPesquisa.setCodtitulo(conex.rs.getInt("codtitulo"));
                System.out.println("Pesquisa feita no banco");
                conex.desconecta();
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(null, "Não foi possivel buscar no bando o titulos\n" +ex);
            }
            return modPesquisa;
        }
        
        public void excluir(ModeloTitulo modExcluir){
            try {
                conex.conexao();
                PreparedStatement pst = conex.con.prepareStatement("delete from titulo where codtitulo=?");
                pst.setInt(1, modExcluir.getCodtitulo());

                pst.execute();
                System.out.println("Titulo deletado");
                conex.desconecta();
                System.out.println("Dados exluidos com sucesso.");
                JOptionPane.showMessageDialog(null, "Dados excluido com sucesso!");
            } catch (SQLException ex) {
                 JOptionPane.showMessageDialog(null, "Não foi possivel excluir o Titulo do bando o aluno.\n" +ex);
            }
        }
        
        public void editar(ModeloTitulo modEditar){
            try {
                conex.conexao();
                PreparedStatement pst = conex.con.prepareStatement("update titulo set prazo=?,isbn=?,edicao=?,ano=?,codautor=?,codarea=? where codtitulo=?");
                pst.setInt(1, modEditar.getPrazo());
                pst.setString(2, modEditar.getIsbn());
                pst.setInt(3, modEditar.getEdição());
                pst.setInt(4, modEditar.getAno());
                pst.setInt(5, modEditar.getCodautor());
                pst.setInt(6, modEditar.getCodArea());
                pst.setInt(7, modEditar.getCodtitulo());
                pst.execute();
                JOptionPane.showMessageDialog(null, "Dados alterados com sucesso!");
                System.out.println("Dados do Titulo alterados com sucesso.");
                conex.desconecta();
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(null, "Dados não alterados.\nErro:"+ex.getMessage());
            }
            }
        
        
    
}
