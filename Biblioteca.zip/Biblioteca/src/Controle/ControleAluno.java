/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controle;

import Arquivos.ConecaoBD;
import Modelos.ModeloAluno;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.swing.JOptionPane;

public class ControleAluno {
    
    
        ConecaoBD conex = new ConecaoBD();
        ModeloAluno mod = new ModeloAluno();
        
        public void Salvar(ModeloAluno mod){
            try {
                conex.conexao();
                PreparedStatement pst = conex.con.prepareStatement("insert into alunos(cpfaluno,cepaluno,nomealuno,endereço,bairroaluno,complementoaluno,verificar) values(?,?,?,?,?,?,?)");
                pst.setInt(1, mod.getCPFAluno());
                pst.setInt(2, mod.getCEPAluno());
                pst.setString(3, mod.getNomeAluno());
                pst.setString(4, mod.getEndereçoALuno());
                pst.setString(5, mod.getBairroAluno());
                pst.setString(6, mod.getComplemento());
                pst.setInt(7, mod.getEmprestimos());
                pst.execute();
                JOptionPane.showMessageDialog(null, "Aluno salvo com sucesso.");
                System.out.println("Dados do aluno salvo no banco.");
                conex.desconecta();
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(null, "Não foi possivel salvar o aluno.\n" +ex);
            }
        }
        
        public ModeloAluno buscaaluno(ModeloAluno modPesquisa){
            
            try {
                conex.conexao();           
                conex.executaSQL("select *from alunos where nomealuno like'%"+modPesquisa.getPesquisa()+"%'");           
                conex.rs.first();           
                modPesquisa.setCPFAluno(conex.rs.getInt("cpfaluno"));                     
                modPesquisa.setCEPAluno(conex.rs.getInt("cepaluno"));             
                modPesquisa.setNomeAluno(conex.rs.getString("nomealuno"));            
                modPesquisa.setEndereçoALuno(conex.rs.getString("endereço"));
                modPesquisa.setBairroAluno(conex.rs.getString("bairroaluno"));
                modPesquisa.setComplemento(conex.rs.getString("complementoaluno"));             
                modPesquisa.setCodaluno(conex.rs.getInt("idaluno"));
                modPesquisa.setEmprestimos(conex.rs.getInt("verificar"));
                System.out.println("Pesquisa feita no banco");
                conex.desconecta();
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(null, "Não foi possivel buscar no bando o aluno.\n" +ex);
            }
            return modPesquisa;
        }
        
        public ModeloAluno buscacodaluno(int Pesquisa){
             ModeloAluno modPesquisa = new ModeloAluno();
            try {

                conex.conexao();           

                conex.executaSQL("select *from alunos where idaluno like'%"+Pesquisa+"%'");  

                conex.rs.first();           
                modPesquisa.setCPFAluno(conex.rs.getInt("cpfaluno"));                     
                modPesquisa.setCEPAluno(conex.rs.getInt("cepaluno"));             
                modPesquisa.setNomeAluno(conex.rs.getString("nomealuno"));            
                modPesquisa.setEndereçoALuno(conex.rs.getString("endereço"));
                modPesquisa.setBairroAluno(conex.rs.getString("bairroaluno"));
                modPesquisa.setComplemento(conex.rs.getString("complementoaluno"));             
                modPesquisa.setCodaluno(conex.rs.getInt("idaluno"));
                modPesquisa.setEmprestimos(conex.rs.getInt("verificar"));
                System.out.println("Pesquisa feita no banco");
                conex.desconecta();
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(null, "Não foi possivel buscar no bando o aluno.\n" +ex);
            }
            return modPesquisa;
        }
        
        public void editar(ModeloAluno modEditar){
            try {
                conex.conexao();
                PreparedStatement pst = conex.con.prepareStatement("update alunos set verificar=? where idaluno=?");
                pst.setInt(1, modEditar.getEmprestimos());
                pst.setInt(2, modEditar.getCodaluno());
                pst.execute();
                JOptionPane.showMessageDialog(null, "Emprestimo adicionado no aluno.");
                conex.desconecta();
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(null, "Dados não alterados no Aluno.\nErro:"+ex.getMessage());
            }
            }
        
        
    
    
}
