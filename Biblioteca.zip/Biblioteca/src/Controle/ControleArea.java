/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controle;

import Arquivos.ConecaoBD;
import Modelos.ModeloAluno;
import Modelos.ModeloArea;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.swing.JOptionPane;

/**
 *
 * @author vinic
 */
public class ControleArea {
    
    
       ConecaoBD conex = new ConecaoBD();
       ModeloArea mod = new ModeloArea();
        
        public void Salvar(ModeloArea mod){
            try {
                conex.conexao();
                PreparedStatement pst = conex.con.prepareStatement("insert into area (nome,descricao) values(?,?)");
                pst.setString(1, mod.getNome());
                pst.setString(2, mod.getDescrição());
                pst.execute();
                JOptionPane.showMessageDialog(null, "Area salvo com sucesso.");
                System.out.println("Dados da Area salvo no banco.");
                conex.desconecta();
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(null, "Não foi possivel salvar a Area.\n" +ex);
            }
        }
        
        public ModeloArea buscaarea(ModeloArea modPesquisa){
            
            try {
                conex.conexao();           
                
                conex.executaSQL("select *from area where nome like'%"+modPesquisa.getPesquisa()+"%'");       
                conex.rs.first();           
                modPesquisa.setNome(conex.rs.getString("nome"));
                modPesquisa.setDescrição(conex.rs.getString("descricao"));
                modPesquisa.setCodarea(conex.rs.getInt("codarea"));
                System.out.println("Pesquisa feita no banco");
                conex.desconecta();
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(null, "Não foi possivel buscar no bando o aluno.\n" +ex);
            }
            return modPesquisa;
        }
        
        public void excluir(ModeloArea modExcluir){
            try {
                conex.conexao();
                PreparedStatement pst = conex.con.prepareStatement("delete from area where codarea=?");
                pst.setInt(1, modExcluir.getCodarea());
                pst.execute();
                System.out.println("Area deletado");
                conex.desconecta();
                System.out.println("Dados exluidos com sucesso.");
                JOptionPane.showMessageDialog(null, "Dados excluido com sucesso!");
            } catch (SQLException ex) {
                 JOptionPane.showMessageDialog(null, "Não foi possivel excluir a Area do bando o aluno.\n" +ex);
            }
        }
        
        public void editar(ModeloArea modEditar){
            try {
                conex.conexao();
                PreparedStatement pst = conex.con.prepareStatement("update area set nome=?,descricao=? where codarea=?");
                pst.setString(1, modEditar.getNome());
                pst.setString(2, modEditar.getDescrição());
                pst.setInt(3, modEditar.getCodarea());
                pst.execute();
                JOptionPane.showMessageDialog(null, "Dados alterados com sucesso!");
                System.out.println("Dados da area alterados com sucesso.");
                conex.desconecta();
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(null, "Dados não alterados.\nErro:"+ex.getMessage());
            }
            }
        
        
    
}
