/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controle;

import Arquivos.ConecaoBD;
import Modelos.ModeloArea;
import Modelos.ModeloAutor;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.swing.JOptionPane;

/**
 *
 * @author vinic
 */
public class ControleAutor {
    
    
        ConecaoBD conex = new ConecaoBD();
       ModeloAutor mod = new ModeloAutor();
        
        public void Salvar(ModeloAutor mod){
            try {
                conex.conexao();
                PreparedStatement pst = conex.con.prepareStatement("insert into autor(nome,sobrenome,titulacao) values(?,?,?)");
                pst.setString(1, mod.getNome());
                pst.setString(2, mod.getSobrenome());
                pst.setString(3, mod.getTitulação());
                pst.execute();
                JOptionPane.showMessageDialog(null, "Autor salvo com sucesso.");
                System.out.println("Dados da Autor salvo no banco.");
                conex.desconecta();
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(null, "Não foi possivel salvar a Area.\n" +ex);
            }
        }
        
        public ModeloAutor buscaarea(ModeloAutor modPesquisa){
            
            try {
                conex.conexao();           
                
                conex.executaSQL("select *from autor where nome like'%"+modPesquisa.getPesquisa()+"%'");       
                conex.rs.first();           
                modPesquisa.setNome(conex.rs.getString("nome"));
                modPesquisa.setSobrenome(conex.rs.getString("sobrenome"));
                modPesquisa.setTitulação(conex.rs.getString("titulacao"));
                modPesquisa.setCod(conex.rs.getInt("codautor"));
                System.out.println("Pesquisa feita no banco");
                conex.desconecta();
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(null, "Não foi possivel buscar no bando o aluno.\n" +ex);
            }
            return modPesquisa;
        }
        
        public void excluir(ModeloAutor modExcluir){
            try {
                conex.conexao();
                PreparedStatement pst = conex.con.prepareStatement("delete from autor where codautor=?");
                pst.setInt(1, modExcluir.getCod());

                pst.execute();
                System.out.println("Autor deletado");
                conex.desconecta();
                System.out.println("Dados exluidos com sucesso.");
                JOptionPane.showMessageDialog(null, "Dados excluido com sucesso!");
            } catch (SQLException ex) {
                 JOptionPane.showMessageDialog(null, "Não foi possivel excluir o Autor do bando o aluno.\n" +ex);
            }
        }
        
        public void editar(ModeloAutor modEditar){
            try {
                conex.conexao();
                PreparedStatement pst = conex.con.prepareStatement("update autor set nome=?,sobrenome=?,titulacao=? where codautor=?");
                pst.setString(1, modEditar.getNome());
                pst.setString(2, modEditar.getSobrenome());
                pst.setString(3, modEditar.getTitulação());
                pst.setInt(4, modEditar.getCod());
                pst.execute();
                JOptionPane.showMessageDialog(null, "Dados alterados com sucesso!");
                System.out.println("Dados do autor alterados com sucesso.");
                conex.desconecta();
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(null, "Dados não alterados.\nErro:"+ex.getMessage());
            }
            }
        
        
    
}
