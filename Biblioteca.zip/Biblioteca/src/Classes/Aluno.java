package Classes;

import Controle.ControleAluno;
import Modelos.ModeloAluno;
import java.util.List;

public class Aluno {
int RA;

public Aluno(int nome) {
	super();
	this.RA = nome;
	
}

public int getNome() {
	return RA;
}

public void setNome(int nome) {
	this.RA = nome;
}

//Metodo que delega a funcionalidade de emprsestar para a classe emprestimo
public boolean emprestar(List<Livro> livros)
{   /* Aqui voc� deve intanciar um objeto emprestimo */
    Emprestimo emprestimo = new Emprestimo();
    emprestimo.emprestar(livros);
    return false;
	/* Aqui voc� deve chamar o metodo emprestar da classe empresitmo*/
	
	
	
}
}
