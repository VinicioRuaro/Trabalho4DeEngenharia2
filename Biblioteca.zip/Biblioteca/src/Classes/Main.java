package Classes;


import Jframes.JFMenuInicial;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
                 
		 JFMenuInicial entrada = new JFMenuInicial();
                 entrada.eu=entrada;
                 entrada.setVisible(true);
		 Scanner entradat = new Scanner (System.in);
		 int[] codigos= {0,0,0,0,0,0,0,0,0,0,0,0,0,0};
		
		 String aluno = entradat.nextLine();
		 System.out.print("Digite o numero de Livros a ser Emprestado: ");
		 int num = entradat.nextInt();
		 int aux;
		 for(int i=0;i<num;i++)
		 {
			 System.out.print("Digite o codigo do livro "+i+":");
			 aux=entradat.nextInt();
			 codigos[i]=aux;
		 }
		 
       
            
    		 
	}

}
