package Classes;

public class Titulo {
int prazo;
public Titulo(int prazo)
{
	this.prazo = prazo;
}
public int getPrazo() {
	return prazo;
}

public void setPrazo(int prazo) {
	this.prazo = prazo;
}

}