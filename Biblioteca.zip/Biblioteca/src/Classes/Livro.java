package Classes;

import Controle.ControleLivro;
import Modelos.ModeloLivro;


public class Livro {

	
	private boolean exemplarBiblioteca;
	Titulo titulo;
        private int cod;

    public boolean getDisponivel() {
        return disponivel;
    }

    public Titulo getTitulo() {
        return titulo;
    }
    

    public void setDisponivel(boolean disponivel) {
        this.disponivel = disponivel;
    }
        private boolean disponivel;

	public Livro(int prazo) {
		super();
		//inst�ncia um titulo e o associa ao livro
		titulo = new Titulo(prazo);
		
		
	}

	public int verPrazo() {
		return titulo.getPrazo();
	}

	
	public boolean verificaLivro()
	{  
            ModeloLivro modlivro = new ModeloLivro();
            ControleLivro control = new ControleLivro();
            modlivro.setPesquisa(cod);
            return exemplarBiblioteca;
           
	   
	}

    public boolean isExemplarBiblioteca() {
        return exemplarBiblioteca;
    }

    public void setExemplarBiblioteca(boolean exemplarBiblioteca) {
        this.exemplarBiblioteca = exemplarBiblioteca;
    }

    public int getCod() {
        return cod;
    }

    public void setCod(int cod) {
        this.cod = cod;
    }
	
}