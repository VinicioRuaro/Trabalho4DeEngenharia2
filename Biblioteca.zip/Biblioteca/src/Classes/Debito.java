package Classes;

import Controle.ControleAluno;
import Modelos.ModeloAluno;

public class Debito {
	int codigoAluno;
	public Debito(int aluno){
		this.codigoAluno =aluno;
	}
	
	public boolean verificaDebito()
	{
            ModeloAluno modAluno = new ModeloAluno();
            ControleAluno controleAluno= new ControleAluno();
            modAluno.setPesquisa(String.valueOf(codigoAluno));
            modAluno=controleAluno.buscaaluno(modAluno);
            
            
	if(modAluno.getEmprestimos()==0)
		 return true;
        else{
		return false;
        }
	}

}
